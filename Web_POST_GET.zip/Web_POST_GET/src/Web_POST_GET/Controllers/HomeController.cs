﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Web_POST_GET.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        [HttpGet("api/Listaprodutos")]
        public JsonResult Listaprodutos(string nomeproduto)
        {
            var listadeProdutos = new List<string>();

            for (int i = 1; i <= 15; i++)
            {
                listadeProdutos.Add(string.Concat(nomeproduto, " - ", i.ToString()));
            }

            return Json(listadeProdutos);
        }


        [HttpPost("api/ListaUsuarios")]
        public JsonResult ListaUsuarios(string nome, string sobrenome)
        {
            var listadeusuarios = new List<string>();

            for (int i = 1; i <= 15; i++)
            {
                listadeusuarios.Add(string.Concat(i.ToString(), " - Nome - ", nome, " - Sobrenome - ", sobrenome));
            }

            return Json(listadeusuarios);
        }
    }
}

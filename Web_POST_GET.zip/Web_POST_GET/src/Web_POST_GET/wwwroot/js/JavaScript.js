﻿var Objetousuario = new Object();

$(function () {
    $('#salvar').click(
        function () {
            Objetousuario.Salvarusuario();
        }
        );

});

Objetousuario.Salvarusuario = function () {
    var nome = $('#nome').val();
    var sobrenome = $('#sobrenome').val();

    var strUrl = "/api/ListaUsuarios"

    $.ajax({

        type: "POST",
        url: strUrl,
        data: { nome: nome, sobrenome: sobrenome },
        dataType: "JSON",
        success: function (data) {
            $('#resultado').empty();
            data.forEach(function (entry) {
                $('#resultado').append(entry + "<br />");
            });
           
        }

    });
}